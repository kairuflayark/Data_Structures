\/***********************************************************************
* Program:
*    Week 13, Genology
*    Brother Helfrich, CS 235
* Author:
*    Br. Helfrich
* Summary: 
*    This is a driver program to exercise the Hash class.  When you
*    submit your program, this should not be changed in any way.  That being
*    said, you may need to modify this once or twice to get it to work.
************************************************************************/

#ifndef WEEK13_H
#define WEEK13_H

#include <list.h>
#include <bst.h>
#include <string>
using namespace std;

struct Person
{
	string surname;
	string givenName;
	string bDay;
	string family1;
	string family2;
};

void readFile(List<Person> people)













#endif